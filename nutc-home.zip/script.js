document.addEventListener('DOMContentLoaded', () => {
    console.log("NUTC 網站已載入");
});