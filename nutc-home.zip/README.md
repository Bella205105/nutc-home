# NUTC Home Page

這是一個為國立臺中科技大學設計的靜態網站首頁，使用 Tailwind CSS 製作，可部署於 GitHub Pages。

## 部署方式

1. 將檔案上傳至 GitHub
2. 啟用 GitHub Pages（main branch）
3. 透過網址存取：`https://Bella205105.github.io/nutc-home/`